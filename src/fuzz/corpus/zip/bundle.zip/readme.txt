reverse-slop corpus seed
